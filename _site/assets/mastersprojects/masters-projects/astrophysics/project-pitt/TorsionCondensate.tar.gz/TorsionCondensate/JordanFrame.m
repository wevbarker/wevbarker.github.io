(*===============*)
(*  JordanFrame  *)
(*===============*)

(*---------------------------------*)
(*  Jordan frame scalar functions  *)
(*---------------------------------*)

Comment@"We will next move over to the scalar-tensor theory.";

Title@"Obtaining the field equations from the metrical analogue in the (physical) Jordan frame";

Comment@"Define the scalar functions for the Jordan conformal frame. These are defined in Eq. (9) of the paper.";

DefTensor[Phi[],M4,PrintAs->"\[Phi]"];
DefTensor[Psi[],M4,PrintAs->"\[Psi]"];

Comment@"Define a scalar function which denotes Mathematica's square root Sqrt.";

DefScalarFunction[Sq,PrintAs->"\[ScriptCapitalQ]"];

Comment@"Define also a constant to manually trace the sign of the time component of the vector field. The need for this (implicit) constant is referred to at the top of Section VI, and I'm hoping that it could be one of the sources of error in the unusual-looking potential.";

DefConstantSymbol[sgn,PrintAs->"\[ScriptS]"];

Comment@"Define the current in (14b), note that the valence of the current is important because it is really a bunch of derivatives.";

DefTensor[J[-a],M4,PrintAs->"\[ScriptCapitalJ]"];

JActivate=MakeRule[{J[-a],4*Sig1*Psi[]^3*CD[-a][Phi[]/Psi[]]-MPl^2*(Alp0+Ups2)*CD[-a][Phi[]]},
	MetricOn->All,ContractMetrics->True];

Print@J[a];

Print@(J[-a]/.JActivate//ToCanonical);

Comment@"Take a moment to remind ourselves how it comes to pass that the Cuscuton does not contribute any energy density using this Lagrangian.";

Print@(Sqrt[-DetG[]]Sqrt[J[a]J[-a]]);

Comment@"Here are the metric field equations from the density above. So we can see that the time-time component will vanish.";

Print@(VarD[G[a,b],CD][Sqrt[-DetG[]]Sqrt[J[a]J[-a]]]);

Comment@"Those last two outputs were just a brief tangent, so now we can carry on.";

Comment@"Define the general Jordan frame metrical analogue in (14a), remembering that the square root is now accommodated by an explicit sign and formal function.";

JordanLagrangianDensity=Sqrt[-DetG[]]*(
		((1/2)*MPl^2*Ups2+Sig3*Phi[]^2
			+(1/2)*(Sig3-Sig2)*Psi[]^2)*RicciScalarCD[]
		+12*(Sig3*CD[-a][Phi[]]*CD[a][Phi[]]/2
			+(1/2)*(Sig3-Sig2)*CD[-a][Psi[]]*CD[a][Psi[]]/2)
			+sgn*Sq[J[-a]*J[a]]
		+(3/4)*MPl^2*((Alp0+Ups2)*Phi[]^2-(Alp0-4*Ups1)*Psi[]^2)
		+(3/2)*(Sig3*Phi[]^4-2*Sig2*Phi[]^2*Psi[]^2+Sig3*Psi[]^4)
	);

Print@(JordanLagrangianDensity//ToCanonical//Simplify);
