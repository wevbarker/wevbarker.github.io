(*=====================*)
(*  xCobaCalculations  *)
(*=====================*)

Print@"We want to avoid the GUI and program entirely within vim...";

Get@FileNameJoin@{NotebookDirectory[],"VimFormat.m"};

Comment@"...that's better. Now commentary written in vim will appear in blue, and these are the lines you should pay closer attention to.";

Title@"Setting up geometric preliminaries";

SetOptions[$FrontEndSession,EvaluationCompletionAction->"ScrollToOutput"];

<<xAct`xTensor`;
<<xAct`xPerm`;
<<xAct`xTras`;
<<xAct`xCoba`;

(*-------------------------------------*)
(*  Definition of Riemannian manifold  *)
(*-------------------------------------*)

Get@FileNameJoin@{NotebookDirectory[],"DefManifold.m"};

(*------------------*)
(*  FLRW spacetime  *)
(*------------------*)

Comment@"Define the scale factor.";

DefScalarFunction[Sf,PrintAs->"\[ScriptA]"];
DefScalarFunction[H,PrintAs->"\[ScriptCapitalH]"];

Sf'[ct_]:=H[ct]*Sf[ct];
Sf''[ct_]:=D[H[ct]*Sf[ct],ct];

Comment@"Define the chart for spherical polar coordinates.";

DefChart[SphericalPolar,M4,{0,1,2,3},{ct[],cr[],ctheta[],cphi[]},ChartColor->Green];

PrintAs@ct^="\[ScriptT]";
PrintAs@cr^="\[ScriptR]";
PrintAs@ctheta^="\[Theta]";
PrintAs@cphi^="\[Phi]";

Comment@"Set the components of the metric to those of flat FLRW.";

MatrixForm[MatrixSphericalPolar=DiagonalMatrix[{1,-Sf[ct[]]^2,-Sf[ct[]]^2*cr[]^2,-Sf[ct[]]^2*cr[]^2*Sin[ctheta[]]^2}]];
MatrixForm@MetricInBasis[G,-SphericalPolar,MatrixSphericalPolar];
MetricCompute[G,SphericalPolar,All,Verbose->False];

(*-----------------------------*)
(*  Minisuperspace Lagrangian  *)
(*-----------------------------*)

Title@"Obtaining the field equations from the minisuperspace Lagrangian which comes from the full Poincaré gauge theory";

Comment@"Define scalar functions of the time coordinate scalar, and functions which will represent the ADM quantities.";

DefScalarFunction[Psis,PrintAs->"\[Psi]"];
DefScalarFunction[Phis,PrintAs->"\[Phi]"];
DefScalarFunction[Vs,PrintAs->"\[ScriptV]"];
DefScalarFunction[Us,PrintAs->"\[ScriptU]"];

Comment@"The minisuperspace Lagrangian, so as to confirm that in the original (physical) Jordan conformal frame this corresponds to the coordinate-imposed metric analogue. As defined in (12) from the paper, we have after an exercise in data entry and double-checking:";

MinisuperspaceLagrangianDensity=(
	((1/2)*MPl^2*Ups2+Sig3*Phis[ct[]]^2+(1/2)*(Sig3-Sig2)*Psis[ct[]]^2)
		*(6*Vs[ct[]]^3*D[Us[ct[]],ct[]]^2+12*Us[ct[]]*Vs[ct[]]^2*D[Us[ct[]],ct[]]*D[Vs[ct[]],ct[]]+6*Us[ct[]]^2*Vs[ct[]]*D[Vs[ct[]],ct[]]^2)
	+12*Sig3*(Us[ct[]]*Vs[ct[]]^3*Phis[ct[]]*D[Us[ct[]],ct[]]+(1/2)*Us[ct[]]^2*Vs[ct[]]^3*D[Phis[ct[]],ct[]]+Us[ct[]]^2*Vs[ct[]]^2*Phis[ct[]]*D[Vs[ct[]],ct[]])
		*D[Phis[ct[]],ct[]]
	+6*(Sig3-Sig2)*(Us[ct[]]*Vs[ct[]]^3*Psis[ct[]]*D[Us[ct[]],ct[]]+(1/2)*Us[ct[]]^2*Vs[ct[]]^3*D[Psis[ct[]],ct[]]+Us[ct[]]^2*Vs[ct[]]^2*Psis[ct[]]*D[Vs[ct[]],ct[]])
		*D[Psis[ct[]],ct[]]
	+4*Sig1*(Psis[ct[]]^2-Phis[ct[]]^2)
		*((3/2)*Us[ct[]]^2*Vs[ct[]]^3*Phis[ct[]]*D[Us[ct[]],ct[]]+(3/2)*Us[ct[]]^3*Vs[ct[]]^2*Phis[ct[]]*D[Vs[ct[]],ct[]]+(3/2)*Us[ct[]]^3*Vs[ct[]]^3*D[Phis[ct[]],ct[]])
	+3*MPl^2*(Alp0+Ups2)
		*(Us[ct[]]^2*Vs[ct[]]^3*Phis[ct[]]*D[Us[ct[]],ct[]]+Us[ct[]]^3*Vs[ct[]]^2*Phis[ct[]]*D[Vs[ct[]],ct[]])
	+(3/4)*Us[ct[]]^4*Vs[ct[]]^3*(2*Sig3*Phis[ct[]]^4-4*Sig2*Phis[ct[]]^2*Psis[ct[]]^2+2*Sig3*Psis[ct[]]^4+MPl^2*(Alp0+Ups2)*Phis[ct[]]^2-MPl^2*(Alp0-4*Ups1)*Psis[ct[]]^2)
);

Print@(MinisuperspaceLagrangianDensity//ToCanonical//Simplify);

Comment@"I'd like to note here a typo in 2006.03581, in that Eq. (12) has the notation to suggest that it would need an extra factor of \[ScriptU]^4\[ScriptV]^3 in order to be gauge covariant (i.e. the measure in flat FLRW spacetime). No such factor is required, so it is safe to take variations directly from the quantity written in that equation.";

Comment@"Mathematica provides some very rudimentary functional tools. We take the Euler-Lagrange equations in the limit of \[ScriptU] and \[ScriptV] post-variations as described in the paper, and simplify to expressions involving only the Hubble number and the scalar fields assuming only that the scale factor never vanishes.";

SimplifyMinisuperspace[Eqn_]:=Module[{SimplifiedEqn},
	SimplifiedEqn=First@Eqn;
	SimplifiedEqn=SimplifiedEqn/(2*3*5*7*Sf[ct[]])^10/.{Vs->Sf,Us[x_]->1,Us'[x_]->0,Us''[x_]->0};
	SimplifiedEqn//=ToCanonical;
	SimplifiedEqn//=Simplify;
	SimplifiedEqn//=Normal;
	SimplifiedEqn//=Numerator;
SimplifiedEqn];

<<VariationalMethods`;

UsEquation=EulerEquations[MinisuperspaceLagrangianDensity,Us[ct[]],ct[]]//SimplifyMinisuperspace;
VsEquation=EulerEquations[MinisuperspaceLagrangianDensity,Vs[ct[]],ct[]]//SimplifyMinisuperspace;
PhisEquation=EulerEquations[MinisuperspaceLagrangianDensity,Phis[ct[]],ct[]]//SimplifyMinisuperspace;
PsisEquation=EulerEquations[MinisuperspaceLagrangianDensity,Psis[ct[]],ct[]]//SimplifyMinisuperspace;

Comment@"The \[ScriptU] equation:";
Print@UsEquation;
Comment@"The \[ScriptV] equation:";
Print@VsEquation;
Comment@"The \[Phi] equation:";
Print@PhisEquation;
Comment@"The \[Psi] equation:";
Print@PsisEquation;

MinisuperspaceEquations={UsEquation,VsEquation,PhisEquation,PsisEquation};

Get@FileNameJoin@{NotebookDirectory[],"JordanFrame.m"};

(*----------------------------------------------------------*)
(*  Some routines to simplify transfer to FLRW coordinates  *)
(*----------------------------------------------------------*)

RawFLRW[Expr_]:=Module[{FLRWExpr=Expr},
	FLRWExpr//=NoScalar;	
	FLRWExpr=FLRWExpr/.{
		Phi[]->Phis[ct[]],
		Psi[]->Psis[ct[]],
		Xs[]->Xss[ct[]],
		Zs[]->Zss[ct[]]
		};	
	FLRWExpr//=ToBasis[SphericalPolar];
	FLRWExpr//=TraceBasisDummy;
	FLRWExpr//=ToValues;
	FLRWExpr//=ToValues;

	(*----------------------------------------*)
	(*  Evaluate at the equator of the chart  *)
	(*----------------------------------------*)

	FLRWExpr=FLRWExpr/.{ctheta[]->Pi/2};

	(*--------------------------------------------------------------------*)
	(*  Now that variations are done, we reveal the square root function  *)
	(*--------------------------------------------------------------------*)

	FLRWExpr=FLRWExpr/.{Sq->Sqrt};
	FLRWExpr];

(*------------------------------------------------------------*)
(*  A wrapper for the above, which looks inside Scalar heads  *)
(*------------------------------------------------------------*)

ToFLRW[Expr_]:=Module[{FLRWExpr=Expr},

	(*-----------------------------------------------------*)
	(*  Even inside scalars, impose the coordinate ansatz  *)
	(*-----------------------------------------------------*)

	FLRWExpr=FLRWExpr/.{xAct`xTensor`Scalar->RawFLRW};

	(*---------------------------------------*)
	(*  Then impose the ansatz on the whole  *)
	(*---------------------------------------*)

	FLRWExpr//=RawFLRW;	

	(*------------------------------------------------------------------*)
	(*  Assume we evaluate at a point in the chart with nonzero radius  *)
	(*------------------------------------------------------------------*)

	FLRWExpr=FLRWExpr/(MPl*2*3*5*7*11*Sf[ct[]]*cr[])^10;
	FLRWExpr//=Simplify;	
	FLRWExpr//=Normal;
	FLRWExpr//=Numerator;

	FLRWExpr//=Simplify;	

	FLRWExpr];

(*-------------------------------------------------*)
(*  Field equations in the Jordan conformal frame  *)
(*-------------------------------------------------*)

JordanLagrangianDensity//=NoScalar;
JordanLagrangianDensity=JordanLagrangianDensity/.JActivate;
JordanLagrangianDensity=JordanLagrangianDensity/.ToTheory;

Comment@"The Jordan frame metrical analogue with the constraints imposed on the couplings.";

Print@JordanLagrangianDensity;

(*------------------------*)
(*  Handling the current  *)
(*------------------------*)

Comment@"This square root is a pattern which will stubbornly remain in the field equations when we make no assumptions. Since we deal only in real quantities, we know (Mathematica does not) that it is equal to the absolute value of the quantity inside the square, or the absolute value of the timelike part of the vector.";

RemainingRoot=J[-a]J[a]/.JActivate/.ToTheory//SeparateMetric[G];
RemainingRoot//=ToFLRW;
RemainingRoot//=Sqrt;


Print@RemainingRoot;

Comment@"This is the timelike part of the vector.";

TimelikePart=J[-a]G[a,{0,-SphericalPolar}]/.JActivate/.ToTheory//ToFLRW;

Print@TimelikePart;

Comment@"This means that we can safely impose the following replacement rule.";

RemoveRoot={RemainingRoot->TimelikePart/sgn};

Print@RemoveRoot;

(*------------------------------------------------------------------------------------*)
(*  A time-consuming section of code, uncomment if you wish to re-make the binaries   *)
(*------------------------------------------------------------------------------------*)

(**)

(*-------------------------------------------------------------------*)
(*  A function to carefully interpret the square root as it appears  *)
(*-------------------------------------------------------------------*)

CarefullyResoreSigns[Expr_]:=Module[{SignedExpr=Expr},

	(*-----------------------------------------*)
	(*  Impose the rule to interpret the root  *)
	(*-----------------------------------------*)

	SignedExpr=SignedExpr/.RemoveRoot;

	(*--------------------------------------------------------------------*)
	(*  We don't expect the sign to ever vanish, so we can divide it out  *)
	(*--------------------------------------------------------------------*)

	SignedExpr=SignedExpr/(MPl*2*3*5*7*11*sgn)^10;
	SignedExpr//=Simplify;	
	SignedExpr//=Normal;
	SignedExpr//=Numerator;

	(*-----------------------------------------------*)
	(*  And since it is a sign, it squares to unity  *)
	(*-----------------------------------------------*)

	SignedExpr=SignedExpr/.{sgn^2->1,sgn^4->1,sgn^6->1};

	SignedExpr//=Simplify;	

SignedExpr];

EinsteinFieldEquations=VarD[G[m,n],CD][JordanLagrangianDensity]//ToCanonical//ContractMetric//ScreenDollarIndices//CollectTensors;
PhiEquation=VarD[Phi[],CD][JordanLagrangianDensity]//ToCanonical//ContractMetric//ScreenDollarIndices//CollectTensors;
PsiEquation=VarD[Psi[],CD][JordanLagrangianDensity]//ToCanonical//ContractMetric//ScreenDollarIndices//CollectTensors;

Comment@"Using the more sophisticated tools out of xAct, we can provide covariant expressions for the components of the field equations from the metrical analogue in the Jordan frame.";

Comment@"The Einstein field equations.";
Print@EinsteinFieldEquations;

Comment@"The expressions for the \[Phi] and \[Psi] equations are somewhat lengthy, but they are likewise covariant.";

Comment@"With some aspects of xCoba, we can also transfer these equations into the background FLRW equations.";

EinsteinFieldEquations//=SeparateMetric[G];
PhiEquation//=SeparateMetric[G];
PsiEquation//=SeparateMetric[G];

PhiEquation//=ToFLRW;
PsiEquation//=ToFLRW;
EinsteinFieldEquations=(ToFLRW/@(EinsteinFieldEquations//ToBasis[SphericalPolar]//ComponentArray));
ConstraintEquation=EinsteinFieldEquations[[1,1]];
AccelerationEquation=EinsteinFieldEquations[[4,4]];

Comment@"The constraint (density) equation.";
Print@ConstraintEquation;
Comment@"The dynamical (pressure) equation.";
Print@AccelerationEquation;
Comment@"The \[Phi] equation.";
Print@PhiEquation;
Comment@"The \[Psi] equation.";
Print@PsiEquation;

Comment@"Now finally we want to be able to remove the square root, using the replacement rule defined above. It is important here to check that there is no dependence on \[ScriptS] in the final answer.";

ConstraintEquation//=CarefullyResoreSigns;
AccelerationEquation//=CarefullyResoreSigns;
PhiEquation//=CarefullyResoreSigns;
PsiEquation//=CarefullyResoreSigns;

Comment@"The constraint (density) equation.";
Print@ConstraintEquation;
Comment@"The dynamical (pressure) equation.";
Print@AccelerationEquation;
Comment@"The \[Phi] equation.";
Print@PhiEquation;
Comment@"The \[Psi] equation.";
Print@PsiEquation;

DumpSave[FileNameJoin@{NotebookDirectory[],"FieldEquations.mx"},{ConstraintEquation,AccelerationEquation,PhiEquation,PsiEquation}];
(**)

Get@FileNameJoin@{NotebookDirectory[],"FieldEquations.mx"};

Comment@"We've obtained the scalar-tensor field equations, and some straightforward checks will be enough for us to show that the minisuperspace equations are precisely the same. We won't do these checks here, but instead continue with the analysis and try to find the details of the background solutions that define the torsion condensate.";

Comment@"Let's work from the minisuperspace equations which we obtained earlier.";

MinisuperspaceEquations=MinisuperspaceEquations/.ToTheory//Simplify;

Comment@"The \[ScriptU] equation.";
Print@MinisuperspaceEquations[[1]];
Comment@"The \[ScriptV] equation.";
Print@MinisuperspaceEquations[[2]];
Comment@"The \[Phi] equation.";
Print@MinisuperspaceEquations[[3]];
Comment@"An algebraic solution for the \[Phi] field based on its field equation.";
sols = Solve[MinisuperspaceEquations[[3]]==0,Phis[ct[]]];
Print@sols;
Comment@"This is the big important line in this script: the rules below define the torsion condensate background solution to the field equations.";
(*coef=-(1+Sqrt[3])/2;*) (*matter dominated*)
coef=1-Sqrt[3];	(*dark energy dominated*)
sols = {{Phis[ct[]]->coef*H[ct[]],Phis'[ct[]]->coef*H'[ct[]],Psis[ct[]]->MPl/Sqrt[-3*Sig1],Psis'[ct[]]->0,Psis''[ct[]]->0}};
Print@sols;

Comment@"This solution is based on the algebraic solution for the \[Phi] field above. Note that the key feature is that the \[Psi] field goes to a specific constant value. Unhelpfully, the solution for \[Phi] looks as though it becomes singular at that value, but in fact detailed analysis of the theory in arXiv:2003.02690, arXiv:2006.03581 and some upcoming papers suggests that the (cosmic time) velocity of \[Psi] will vanish faster than the denominator (to see why this is true, you can look at Eq. (116) on page 19 of arXiv:2003.02690, and recall that the torsion condensate or correspondence solution -- same thing -- will be reached early in the matter-dominated epoch such that the fractional difference in \[CurlyPi] decays like a power law in conformal time). As a result, the \[Phi] field is just proportional to the Hubble number.";

Comment@"The \[Psi] equation. This is essentially a Klein-Gordon equation.";
Print@MinisuperspaceEquations[[4]];

Comment@"The combination of the \[ScriptU] and \[ScriptV] equations in which the derivative of the Hubble number has been eliminated. This corresponds to the time-time Einstein equation, or the Friedmann constraint equation.";

eq1=MinisuperspaceEquations[[1]];

eq2=MinisuperspaceEquations[[2]];

MinisuperspaceConstraintEquation=(eq1/Coefficient[eq1,Derivative[1][H][ct[]]])-(eq2/Coefficient[eq2,Derivative[1][H][ct[]]]);
MinisuperspaceConstraintEquation//=Simplify;
MinisuperspaceConstraintEquation//=Normal;
MinisuperspaceConstraintEquation//=Numerator;

Print@MinisuperspaceConstraintEquation;

Comment@"Now substituting the torsion condensate background solution into the Friedmann constraint equation.";

neweqn = MinisuperspaceConstraintEquation/.sols[[1]];
neweqn//=Simplify;
neweqn//=Normal;
neweqn//=Numerator;

Print@neweqn;

Print@Collect[neweqn,Psis'[ct[]]];

Comment@"We know from arXiv:2006.03581, in the paragraph below Eq. (27), that one of those torsion couplings can be interpreted as an emergent cosmological constant.";

DefConstantSymbol[Lamb,PrintAs->"\[CapitalLambda]"];
neweqn = neweqn/.{Ups1->Lamb*Sig1/MPl^2};

neweqn//=Simplify;
neweqn//=Normal;
neweqn//=Numerator;
Print@neweqn;

Comment@"Now recall that we didn't bother to add any matter in the derivation above. We can re-insert it here in a sneaky way, just by recalling that it must add with the cosmological constant in the usual manner (in order for \[CapitalLambda] to have been given this interpretation in the first place).  ";

DefScalarFunction[Rhos,PrintAs->"\[Rho]"];

neweqn = neweqn/.{Lamb->Lamb-Rhos[ct[]]/(3*Sig1*Psis[ct[]]^2)};
neweqn = neweqn/.sols[[1]];
neweqn//=Simplify;
neweqn//=Normal;
neweqn//=Numerator;
Print@neweqn;

Comment@"Okay, so this last equation above looks like a healthy statement of the first Friedmann equation. Remember that we obtained this equation from the field equations of the PGT/metrical analogue, and then imposed the torsion condensate/correspondence solution on the values of the fields. The consequence of imposing the correspondence solution is that the background cosmological dynamics are precisely those of GR.";

Comment@"One last thing which would be nice to check, is that the correspondence solution also satisfies the field equation for the \[Psi] field.";

neweqn = MinisuperspaceEquations[[4]]/.sols[[1]];
neweqn//=Simplify;
neweqn//=Normal;
neweqn//=Numerator;
Print@neweqn;

Quit[];

(*==========================*)
(*  Current end of script!  *)
(*==========================*)
