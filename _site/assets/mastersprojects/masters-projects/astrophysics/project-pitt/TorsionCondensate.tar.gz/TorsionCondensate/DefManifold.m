(*===============*)
(*  DefManifold  *)
(*===============*)

DefManifold[M4,4,IndexRange[{a,z}]];
AddIndices[TangentM4,{a1,b1,c1,d1,e1,f1,g1,h1,i1,j1,k1,l1,n1,m1,o1,p1,q1,r1,s1,t1,u1,v1,w1,x1,y1,z1}];

GSymb="\!\(\*OverscriptBox[\(\[ScriptG]\), \(\[Degree]\)]\)";
DefMetric[-1,G[-a,-b],CD,{";","\!\(\*OverscriptBox[\(\[Del]\), \(\[SmallCircle]\)]\)"},PrintAs->GSymb,SymCovDQ->True];

(*-----------------------------------------------------------------------*)
(*  Relabeling of the indices so that we can type Roman and look Greek!  *)
(*-----------------------------------------------------------------------*)

StandardIndices=ToString/@Alphabet[];
ExtendedIndices=ToExpression@(ToString@#<>"1")&/@StandardIndices;

GeoStandardIndicesSymb=(ToString@#)&/@Evaluate@((#[[2]])&/@{
	{a,"\[Alpha]"},
	{b,"\[Beta]"},
	{c,"\[Chi]"},
	{d,"\[Delta]"},
	{e,"\[Epsilon]"},
	{f,"\[Phi]"},
	{g,"\[Gamma]"},
	{h,"\[Eta]"},
	{i,"\[Iota]"},
	{j,"\[Theta]"},
	{k,"\[Kappa]"},
	{l,"\[Lambda]"},
	{m,"\[Mu]"},
	{n,"\[Nu]"},
	{o,"\[Omicron]"},
	{p,"\[Pi]"},
	{q,"\[Omega]"},
	{r,"\[Rho]"},
	{s,"\[Sigma]"},
	{t,"\[Tau]"},
	{u,"\[Upsilon]"},
	{v,"\[Psi]"},
	{w,"\[Omega]"},
	{x,"\[Xi]"},
	{y,"\[CurlyPhi]"},
	{z,"\[Zeta]"}});
GeoExtendedIndicesSymb=ToString@ToExpression@(ToString@#<>"'")&/@GeoStandardIndicesSymb;

(PrintAs@Evaluate@#1^=Evaluate@#2)&~MapThread~{ToExpression/@StandardIndices,GeoStandardIndicesSymb};
(PrintAs@Evaluate@#1^=Evaluate@#2)&~MapThread~{ToExpression/@ExtendedIndices,GeoExtendedIndicesSymb};

(*----------------------------------------------------*)
(*  Coupling constants used in the metrical analogue  *)
(*----------------------------------------------------*)

Comment@"Define a Planck mass.";

DefConstantSymbol[MPl,PrintAs->"\(\*SubscriptBox[\(\[ScriptCapitalM]\), \(Pl\)]\)"];

Comment@"Define some dimensionless cosmological couplings.";

DefConstantSymbol[Ups1,PrintAs->"\(\*SubscriptBox[\(\[Upsilon]\), \(1\)]\)"];
DefConstantSymbol[Ups2,PrintAs->"\(\*SubscriptBox[\(\[Upsilon]\), \(2\)]\)"];
DefConstantSymbol[Alp0,PrintAs->"\(\*SubscriptBox[\(\[Alpha]\), \(0\)]\)"];
DefConstantSymbol[Sig1,PrintAs->"\(\*SubscriptBox[\(\[Sigma]\), \(1\)]\)"];
DefConstantSymbol[Sig2,PrintAs->"\(\*SubscriptBox[\(\[Sigma]\), \(2\)]\)"];
DefConstantSymbol[Sig3,PrintAs->"\(\*SubscriptBox[\(\[Sigma]\), \(3\)]\)"];

Comment@"We will define the conditions which restrict to the theory of interest. This theory is considered in arXiv:2006.03581, and corresponds to Case 2 in arXiv:1910.14197. It is an extension of the theory considered in arXiv:2003.02690 (which itself corresponds to Case 16 in arXiv:1910.14197), because it allows for nonzero value of \*SubscriptBox[\(\[Upsilon]\), \(1\)]. The effect of this extension is to introduce an emergent cosmological constant into the theory, as we will see.";

ToTheory={Alp0->0,Sig3->0,Sig2->Sig1,Ups2->-4/3};

Print@ToTheory;
