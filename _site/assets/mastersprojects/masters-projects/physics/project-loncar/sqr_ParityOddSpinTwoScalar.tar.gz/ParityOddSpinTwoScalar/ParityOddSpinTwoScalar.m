(*=====================*)
(*  xCobaCalculations  *)
(*=====================*)

<<VimFormat`;

Title@"Marco's parity-odd spin-two scalar";

PartIIIProject@"The purpose of this script is to compute the scalar part of the parity-odd spin-two mode in the connection, by analogy to standard SVT techniques.";

SetOptions[$FrontEndSession,EvaluationCompletionAction->"ScrollToOutput"];

<<xAct`xTensor`;
<<xAct`xPerm`;
<<xAct`xTras`;
<<xAct`xCoba`;

(*-------------------------------------*)
(*  Definition of Riemannian manifold  *)
(*-------------------------------------*)

Comment@"This time define our manifold to be Euclidean, with three dimensions.";

Get@FileNameJoin@{NotebookDirectory[],"DefManifold.m"};

DefTensor[Phi[],M3,PrintAs->"\[Phi]"];

Comment@"Now we define the rank-three tensor which will represent the mode.";

DefTensor[T[-a,-b,-c],M3,PrintAs->"\[ScriptCapitalT]"];

Expr=T[-a,-b,-c];
DisplayExpression@Expr;

Comment@"Note that we don't assume any symmetry for this tensor yet. We will build an ansatz below, and gradually symmetrise it.";

Comment@"For example the antisymmetry of the Levi-Civita symbols means that there is no pseudoscalar mode buried in this tensor, since we know that the tensor will end up being symmetric in its first pair of indices. For now however, a contraction with the epsilon suggests that there might be such a mode.";

Expr=HoldForm@(epsilonG[-a,-b,-c]*epsilonG[d,e,f]*T[-d,-e,-f]);
DisplayExpression@Expr;
Expr//=ReleaseHold;
DisplayExpression@Expr;
Expr//=ToCanonical;
Expr//=ContractMetric;
Expr//=ScreenDollarIndices;
DisplayExpression@Expr;

Comment@"Another point is that I'd previously recommended you use some defined functions to construct your ansatz. We can try this, e.g. as follows.";

Expr=HoldForm@MakeContractionAnsatz[G[-a,-b]*CD[-c]@Phi[],IndexList[-a,-b,-c]];
DisplayExpression@Expr;
(*
Expr//=ReleaseHold;
DisplayExpression@Expr;
*)

Comment@"Try it yourself by removing the comments, but as suspected, this is pretty trivial! As often happens in computer algebra, it is much easier to do the whole thing by hand.";

Comment@"Define first some constants.";

DefConstantSymbol[C1];
DefConstantSymbol[C2];
DefConstantSymbol[C3];
DefConstantSymbol[C4];

Comment@"Now develop the ansatz.";

Ansatz=(
	C1*G[-a,-b]*CD[-c]@Phi[]
	+C2*(G[-a,-c]*CD[-b]@Phi[]+G[-b,-c]*CD[-a]@Phi[])
	+C3*CD[-a]@CD[-b]@CD[-c]@Phi[]
	+C4*(epsilonG[-b,-c,e]*CD[-a]@CD[-e]@Phi[]+epsilonG[-a,-c,e]*CD[-b]@CD[-e]@Phi[])
);


TActivate=MakeRule[{T[-a,-b,-c],Evaluate[Ansatz]},
	MetricOn->All,ContractMetrics->True];

Expr=T[-a,-b,-c];
DisplayExpression@Expr;
Expr=Expr/.TActivate;
Expr//=ToCanonical;
Expr//=ContractMetric;
Expr//=CollectTensors;
Expr//=ScreenDollarIndices;
DisplayExpression@Expr;

Comment@"So that looks like a fairly general ansatz, we have four unknown coefficients.";

Comment@"The only restriction in concocting this ansatz that we imposed so far was for symmetry in the first pair of indices (since it was so easy to insist on). Let's just check that this symmetry works out.";

Expr=T[-a,-b,-c]-T[-b,-a,-c];
DisplayEquation@Expr;
Expr=Expr/.TActivate;
Expr//=ToCanonical;
Expr//=ContractMetric;
Expr//=CollectTensors;
Expr//=ScreenDollarIndices;
Expr//=HoldForm;
DisplayEquation@Expr;

Comment@"Okay, so that is fine. The symmetry condition knocks out 3*3=9 d.o.f, and it needs no extra condition on the unknown constants to be already true. We have 3*3*3-9=18 d.o.f remaining.";

Comment@"Now let's try the no-trace condition across the non-symmetric indices, which knocks out 3 d.o.f. We have 18-3=15 d.o.f remaining.";

Expr=T[-a,-b,a];
DisplayEquation@Expr;
Expr=Expr/.TActivate;
Expr//=ToCanonical;
Expr//=ContractMetric;
Expr//=CollectTensors;
Expr//=ScreenDollarIndices;
DisplayEquation@Expr;

Comment@"So from this we learn that we need the following constraints.";

Expr=ToConstantSymbolEquations[Expr==0];
DisplayExpression@Expr;

Comment@"Now we move on to the trace on the symmetric pair of indices. Again we have 15-3=12 d.o.f remaining.";

Expr=T[-a,a,-c];
DisplayEquation@Expr;
Expr=Expr/.TActivate;
Expr//=ToCanonical;
Expr//=ContractMetric;
Expr//=CollectTensors;
Expr//=ScreenDollarIndices;
DisplayEquation@Expr;

Comment@"So from this we learn that we need the following constraints.";

Expr=ToConstantSymbolEquations[Expr==0];
DisplayExpression@Expr;

Comment@"However, this is a problem since the final constraint in this series is spurious. To see this, notice how it comes from the term where the Levi-Civita symbol is contracted over a spatial Hessian operator. Of course this term must vanish, because div of curl vanishes! The reason xAct can't get rid of this term has to do with the fact that covariant derivatives are generally non-commuting. There are ways around this using xTras or perhaps PD, but for now it is just a minor bug. The important result is that the system imposed on C1 and C2 by this set of constraints and the previous set is singular: both C1 and C2 must be zero, along with C3, though C4 need not be.";

PartIIIProject@"Now let's try that cyclic identity. Counting the number of d.o.f removed by this identity is a bit of a fiddle. To understand what is happening, I think you can argue as follows. Consider instances of the equation where all indices are unequal, there are 3*2*1=6 of these. However you can massage each such instance using the symmetry in the first pair of indices to show that they all remove only 1 d.o.f. Next consider cases where only two indices are equal, there are 3*2+3*2+3*2=18 of these, but again 3*2+3*2=12 are doubly-counted when you use symmetry in the first pair, leaving apparently 6 d.o.f removed by such cases. Next there are 3*1*1=3 cases with all indices equal. Okay, so that means 1+6+3=10 d.o.f are additionally removed. But this is a disaster since we whittled the tensor down to 12 d.o.f by the time we considered the cyclic symmetry, so we would have only 2 d.o.f left to span a massive spin-2 mode, which ought to have 2*2+1=5 d.o.f. What has happened, is that you can actually pair up each of the all-indices-equal equations with the appropriate two of the two-indices-equal equations to show that the first-pair-traceless condition actually implies the first-last-pair-traceless condition (or vice versa). Therefore, either the cyclic identity over-counts the number of removed d.o.f by three, or we over-counted by three before we got here, depending on perspective. Accordingly, the condition is indeed enough to leave us with a spin-2 state. You should certainly prove this convincingly in your Part III report, rather than relying on this commentary.";

Expr=T[-a,-b,-c]+T[-c,-a,-b]+T[-b,-c,-a];
DisplayEquation@Expr;
Expr=Expr/.TActivate;
Expr//=ToCanonical;
Expr//=ContractMetric;
Expr//=CollectTensors;
Expr//=ScreenDollarIndices;
DisplayEquation@Expr;

Comment@"So from this we learn that we need the following constraints.";

Expr=ToConstantSymbolEquations[Expr==0];
DisplayExpression@Expr;

Comment@"That's fine, it is consistent with everything apart from C4 vanishing.";

Comment@"Finally, for pedantry, we confirm that the epsilon contraction goes away.";

Expr=epsilonG[a,b,c]*T[-a,-b,-c];
DisplayEquation@Expr;
Expr=Expr/.TActivate;
Expr//=ToCanonical;
Expr//=ContractMetric;
Expr//=CollectTensors;
Expr//=ScreenDollarIndices;
Expr//=HoldForm;
DisplayEquation@Expr;

Comment@"And it does!";

PartIIIProject@"Based on this, it looks as though it should be very straightforward to knock up the scalar part of the parity-odd spin-2 mode.";

Quit[];
