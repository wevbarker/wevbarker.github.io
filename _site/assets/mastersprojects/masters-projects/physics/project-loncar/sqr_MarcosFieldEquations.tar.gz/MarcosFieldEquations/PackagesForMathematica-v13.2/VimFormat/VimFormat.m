(*=============*)
(*  VimFormat  *)
(*=============*)

BeginPackage["VimFormat`"];

Comment::usage="Comment";
Title::usage="Title";
Section::usage="Section";
Subsection::usage="Subsection";
DisplayEquation::usage="DisplayEquation";
DisplayExpression::usage="DisplayExpression";
PartIIIProject::usage="PartIIIProject";

Begin["VimFormat`Private`"];

PartIIIProject[Expr_?StringQ]:=Module[{},
	CellPrint@TextCell[TextGrid[{{Style["Connection to Part III project",Bold],Expr}},Frame->All],Darker@Green,"Text",Background->Yellow]];

Comment[Expr_?StringQ]:=Module[{},
	CellPrint@TextCell[Expr,Darker@Green,"Text"]];

Title[Expr_?StringQ]:=Module[{},
	CellPrint@TextCell[Expr,40,Darker@Green,Underlined,Bold,"Text"]];

Section[Expr_?StringQ]:=Module[{},
	CellPrint@TextCell[Expr,30,Darker@Green,Underlined,Bold,"Text"]];

Subsection[Expr_?StringQ]:=Module[{},
	CellPrint@TextCell[Expr,20,Darker@Green,Underlined,"Text"]];

DisplayEquation[Expr_]:=CellPrint@ExpressionCell[Expr==0,Background->LightGreen,"DisplayFormulaNumbered"];

DisplayExpression[Expr_]:=CellPrint@ExpressionCell[Expr,Background->LightGreen,"DisplayFormulaNumbered"];

End[];
EndPackage[];
