(*===========================*)
(*  PresentIrrepConventions  *)
(*===========================*)

Comment@"Here is a quick reminder of our irrep conventions for the torsion.";
Expr=T[m,-n,-s]/.TSO13Activate//ToNewCanonical;
DisplayExpression@Expr;

Comment@"And we also want to see what the teleparallel Lagrangian looks like, this is the double-bar T symbol which must be multiplied by the measure and half the Planck mass, with a positive sign (see eq. (15) in arXiv:2006.03581).";
Expr=(1/4)T[-i,-j,-k]T[i,j,k]+(1/2)T[-j,-i,-k]T[i,j,k]-T[k,-j,-k]T[i,j,-i]/.TSO13Activate//ToNewCanonical;
DisplayExpression@Expr;

Comment@"We will also take a look at our irrep conventions for the spin tensor.";

Expr=H[k,-m]Sigma[m,-i,-j];
DisplayExpression@Expr;
Expr=Expr/.SigmaSO13Activate//ToNewCanonical;
DisplayExpression@Expr;

Comment@"Some care has to be taken when understanding how the vector and axial vector parts of the torsion couple to the respective parts of the spin tensor. The reason for this is that the spin tensor is constructed, as per the discussion above, with two Lorentz indices, and so in the stress-energy field equation there is a possible factor of two that can go missing unless the indices are kept carefully tracked. When we go over to the GeoHiGGS second-order formulation in the next part of the script, all appearances of the translational gauge field and its inverse are simply replaced by the Kroneker symbol. This is safe in the gravity sector of the theory, but not in the matter coupling.";

Comment@"Now we assume that every instance of an epsilon tensor appears with lowered Greek indices in the second-order formalism, so that it is safe to consider this equal to the original epsilon (with Roman indices assumed) with all indices contracted with translational (not inverse) gauge fields.";
EpsilonTangentSpaceConvert=MakeRule[{epsilonG[-a,-b,-c,-d],
		B[i,-a]B[j,-b]B[k,-c]B[l,-d]epsilonG[-i,-j,-k,-l]},
		MetricOn->All,ContractMetrics->True];
DisplayExpression@EpsilonTangentSpaceConvert;

Comment@"Note that the above output is a rule to be used internally by the script, not a mathematical expression. We will occasionally display such rules below as we define them.";

Comment@"Moreover, Greek-index curved-metric tensors will always appear so as to satisfy the following rules, where we use the flat-space metric of HiGGS as a temporary abuse of notation.";
BTangentSpaceConvert=MakeRule[{B[i,m]B[j,-m],
		G[i,j]},
		MetricOn->All,ContractMetrics->True];
HTangentSpaceConvert=MakeRule[{H[-i,m]H[-j,-m],
		G[-i,-j]},
		MetricOn->All,ContractMetrics->True];
DisplayExpression@BTangentSpaceConvert;
DisplayExpression@HTangentSpaceConvert;

Comment@"Here is the part of the Lagrangian in which the torsion is coupled to spin.";
Expr=(1/4)*H[m,-z]Sigma[z,-i,-j]*(
	T[s,-e,-m1]B[i,-s]H[j,e]H[-m,m1]
	-T[s,-r,-p]B[-m,-s]H[i,r]H[j,p]
	+T[s,-m1,-e]B[j,-s]H[-m,m1]H[i,e]
);
DisplayExpression@Expr;

Comment@"Here is the expression expanded according to the above rules.";

Expr=Expr/.TSO13Activate//ToNewCanonical;
Expr//=ToNewCanonical;
Expr=Expr/.EpsilonTangentSpaceConvert//ToNewCanonical;
Expr//=ToNewCanonical;
Expr=Expr/.SigmaSO13Activate//ToNewCanonical;
Expr//=ToNewCanonical;
Expr=Expr/.BTangentSpaceConvert//ToNewCanonical;
Expr//=ToNewCanonical;
Expr=Expr/.HTangentSpaceConvert//ToNewCanonical;
Expr//=ToNewCanonical;
DisplayExpression@Expr;

Comment@"The factors of the translational gauge field which appear here will be needed when we reconstruct the effective second-order theory at the end of the script, but this process will not be made explicit. Moreover, we note that it is better to assume a very general form for the matter spin tensor, such that the specific couplings between different fermion currents and the torsion are basically obscured.";
