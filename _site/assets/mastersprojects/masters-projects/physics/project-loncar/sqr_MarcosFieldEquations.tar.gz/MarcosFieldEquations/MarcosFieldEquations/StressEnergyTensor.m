(*======================*)
(*  StressEnergyTensor  *)
(*======================*)

Subsection@"The stress-energy tensor";

Comment@"Define the stress-energy tensor equation. In general, we will refer to an `equation' as an xTensor expression which we understand to vanish on the shell, accordingly we do not always make the equality explicit.";

StressEnergyEquation=(
	-CD[-m][BGPi[-i,x,y]H[-x,n]H[-y,m]]
	+A[l,-i,-m]BGPi[-l,x,y]H[-x,n]H[-y,m]
	+T[p,-k,-i]BGPi[-p,k,y]H[-y,n]
	+(1/2)R[p,q,-k,-i]AGPi[-p,-q,k,y]H[-y,n]
	+Lapse[]J[](
		T[q,-k,-l](
				( 
					Bet1 PT1[-x,y,z,-q,k,l]
					+Bet2 PT2[-x,y,z,-q,k,l]
					+Bet3 PT3[-x,y,z,-q,k,l]
				)T[x,-y,-z]
				+( 
					cBet1 PT1[-x,y,z,-q,k,l]
					+cBet2 PT2[-x,y,z,-q,k,l]
					+cBet3 PT3[-x,y,z,-q,k,l]
				)TLambda[x,-y,-z]
			)
			+R[q,j,-k,-l](
				( 
					Alp1 PR1[-x,-w,y,z,-q,-j,k,l]
					+ Alp2 PR2[-x,-w,y,z,-q,-j,k,l]
					+ Alp3 PR3[-x,-w,y,z,-q,-j,k,l]
					+ Alp4 PR4[-x,-w,y,z,-q,-j,k,l]
					+ Alp5 PR5[-x,-w,y,z,-q,-j,k,l]
					+ Alp6 PR6[-x,-w,y,z,-q,-j,k,l]
				)R[x,w,-y,-z]
				+( 
					cAlp1 PR1[-x,-w,y,z,-q,-j,k,l]
					+ cAlp2 PR2[-x,-w,y,z,-q,-j,k,l]
					+ cAlp3 PR3[-x,-w,y,z,-q,-j,k,l]
					+ cAlp4 PR4[-x,-w,y,z,-q,-j,k,l]
					+ cAlp5 PR5[-x,-w,y,z,-q,-j,k,l]
					+ cAlp6 PR6[-x,-w,y,z,-q,-j,k,l]
				)RLambda[x,w,-y,-z]
			)-(MPl^2/2)R[q,j,k,l]G[-q,-k]G[-j,-l]
		)H[-i,n]
	);

Comment@"In terms of the generalised momenta, the Riemann-Cartan curvature, the torsion, and the gauge fields, and also in terms of projection operators which are used to define the various quadratic invariants, the left hand side of the stress-energy equation as expressed in the first line of Eq. (3.24b) on page 50 of Blagojević is as follows.";

StressEnergyEquation//=ToCanonical;
StressEnergyEquation//=ScreenDollarIndices;
DisplayExpression@StressEnergyEquation;

Comment@"We now impose the restriction on the coupling constants to go over to the most general case studied, and then we expand the projection operators and the generalised momenta. We subtract the right hand side, i.e. the (asymmetric) matter stress-energy tensor, to form the stress-energy equation.";

StressEnergyEquation=StressEnergyEquation/.ToTheory;
StressEnergyEquation=StressEnergyEquation/.GPiActivate;
StressEnergyEquation//=ToNewCanonical;
StressEnergyEquation=StressEnergyEquation/.PActivate;
StressEnergyEquation//=ToNewCanonical;
StressEnergyEquation=StressEnergyEquation/.ToStrengths;
StressEnergyEquation//=ToNewCanonical;
StressEnergyEquation//=xAct`HiGGS`Private`CDToGaugeCovD;
StressEnergyEquation//=ToNewCanonical;

StressEnergyEquation=(Tau[n,-i]-StressEnergyEquation)/(J[]Lapse[])//ToNewCanonical;
DisplayEquation@StressEnergyEquation;

Comment@"This equation is nearly ready to use, but the (asymmetric) stress-energy tensor of matter first needs some attention. This is because it still depends on the contorsion, and later on in the analysis we will need to refer only to the metric-based part, from which the symmetric Einstein stress-energy tensor is eventually derived. Before moving on to the spin equations therefore, we will explore this matter.";

Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","Contorsion.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","SecondOrderSplitting.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","Variations.m"};

Comment@"Now the second order formalism `splitting' of the stress-energy current is understood, we will `split' the stress-energy equation.";

StressEnergyEquation=StressEnergyEquation/.SplitStressEnergy;
StressEnergyEquation//=ToNewCanonical;
DisplayEquation@StressEnergyEquation;

Comment@"This then is the final form of the stress-energy equation in the first-order formalism. How does it differ from the first version of the equation which we wrote down above? The matter stress-energy tensor has been decomposed into a metric-based part and a series of terms bilinear in the torsion and the matter spin tensor. The gravitational part of the field equations is unaffected.";

PartIIIProject@"This equation is the stress-energy equation which should give rise to some of the cosmological perturbation equations. Remember that we can neglect the spin tensor, that the field strength tensors have only Roman indices, and that Greek indices are provided by the matter stress-energy tensor and the (inverse) translational gauge field wherever it appears. The factor of caligraphic J multiplied by caligraphic N is intended to mean the determinant of the translational gauge field, I've just written it out in 3+1 notation. I'd recommend contracting this equation with the tetrad to produce two raised Greek indices, and then extracting the symmetric part (the Einstein equations) and the antisymmetric part (which you should prove is merely an identity, with the help of the spin equation later on).";

Comment@"We also construct a replacement rule to convert the torsionless stress-energy tensor into gravitational variables, i.e. torsion, Riemann-Cartan curvature and multiplier fields, according to this stress-energy equation.";

TauToGravity=MakeQuotientRule[{TorsionlessTau[n,-i],Evaluate[StressEnergyEquation]},
	MetricOn->All,ContractMetrics->True,Method->"Coefficient"];
