(*=========================*)
(*  MarcosFieldEquations  *)
(*=========================*)

<<VimFormat`;

Title@"Marco's field equations";

PartIIIProject@"These calculations are designed for your Part III project. Throughout, commentary takes the form of green text. Citations, where needed, will be managed by direct reference to arXiv numbers. One exception is the source referred to throughout as `Blagojević'; this pertains to the book `Gravitation and Gauge Symmetries'.";

Subsection@"Loading HiGGS and GeoHiGGS";

Comment@"For these calculations, we will use the HiGGS and GeoHiGGS packages. Note that GeoHiGGS was not developed for public release, and so is not documented. The versions of HiGGS and GeoHiGGS used for the computations here are both developer-only, and so we include copies of the sources with the tarball.";

<<xAct`GeoHiGGS`;

Comment@"All the requisite packages have now been loaded, so we can proceed with the computations.";

Section@"1. Deriving the field equations";

Comment@"HiGGS is designed to study the full ten-parameter Poincaré gauge theory, including nine extra parameters which activate various Lagrange multipliers as defined in arXiv:2205.13534. As a first step, we define the most general case of the set of theories we are interested in by constructing a rule which constrains the Lagrangian couplings.";

MPlSymb="\!\(\*SubscriptBox[\(\[ScriptCapitalM]\), \(Pl\)]\)";
DefConstantSymbol[MPl,PrintAs->MPlSymb];

ToTheory={Alp1->0,Alp2->0,Alp3->0,Alp4->0,Alp6->0,Bet1->0,Bet2->0,Bet3->0,cAlp1->0,cAlp2->0,cAlp3->0,cAlp4->0,cAlp5->0,cAlp6->0,cBet1->0,cBet2->0,cBet3->0};
DisplayExpression@ToTheory;

Comment@"These rules are used to disable most of the coupling in the general theory. The couplings which are not suppressed are those which appear in the Lagrangian. Specifically the fifth alpha-hat coupling, which mediates the quadratic Riemann-Cartan-Maxwell invariant. These remaining couplings will appear in the equations below.";

(*===================================*)
(*  Initial computations with HiGGS  *)
(*===================================*)

Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","GeneralisedMomenta.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","StressEnergyTensor.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","SpinTensor.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","StressEnergyTensorConservation.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","SpinTensorConservation.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","SpinEquationParts.m"};
Get@FileNameJoin@{NotebookDirectory[],"MarcosFieldEquations","PresentIrrepConventions.m"};

Quit[];
