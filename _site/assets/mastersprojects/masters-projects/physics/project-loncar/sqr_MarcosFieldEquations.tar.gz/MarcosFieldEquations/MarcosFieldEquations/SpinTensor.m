(*==============*)
(*  SpinTensor  *)
(*==============*)

Subsection@"The spin tensor";

Comment@"Having studied the general stress-energy equation, we turn to the spin-torsion equation. The spin tensor is defined in Eq. (3.21) on p. 48 of Blagojević.";

SpinEquation=(
	-CD[-m][AGPi[-i,-j,x,y]H[-x,n]H[-y,m]]
	+A[l,-i,-m]AGPi[-l,-j,x,y]H[-x,n]H[-y,m]
	+A[l,-j,-m]AGPi[-i,-l,x,y]H[-x,n]H[-y,m]
	+BGPi[-i,-j,y]H[-y,n]-BGPi[-j,-i,y]H[-y,n]
);

Comment@"Once again, in terms of the generalised momenta and the gauge fields, the left hand side of the spin equation as expressed in the second line of Eq. (3.24b) on page 50 of Blagojević is as follows.";

SpinEquation//=ToCanonical;
SpinEquation//=ScreenDollarIndices;
DisplayExpression@SpinEquation;

Comment@"We now impose the restriction on the coupling constants to go over to the most general case studied, and then we expand the projection operators and the generalised momenta. We subtract the right hand side, i.e. the matter spin tensor, to form the spin equation.";

SpinEquation=SpinEquation/.ToTheory;
SpinEquation=SpinEquation/.GPiActivate;
SpinEquation//=ToNewCanonical;
SpinEquation=SpinEquation/.PActivate;
SpinEquation//=ToNewCanonical;
SpinEquation=SpinEquation/.ToStrengths;
SpinEquation//=ToNewCanonical;
SpinEquation//=xAct`HiGGS`Private`CDToGaugeCovD;
SpinEquation//=ToNewCanonical;

SigmaToGravity=MakeRule[{ Sigma[n,-i,-j],Evaluate[SpinEquation]},MetricOn->All,ContractMetrics->True];
SpinEquation=(Sigma[n,-i,-j]-SpinEquation)/(J[]Lapse[])//ToNewCanonical;

DisplayEquation@SpinEquation;

Comment@"This time we do not need to further decompose the matter sources, and so this constitutes the final form of the spin equations in the first-order formalism.";

PartIIIProject@"This is the spin equation, from which additional cosmological perturbation equations can be derived. You recall that the spin equation is obtained by taking variational derivatives of the action with respect to the rotational gauge field. Hence, the indices of the equation are precisely those of the rotational gauge field itself. That means that you can go ahead and decompose this equation just as you did the rotational gauge field, and the torsion tensor example I gave you earlier. Remember that the spin tensor itself can be set to zero.";
