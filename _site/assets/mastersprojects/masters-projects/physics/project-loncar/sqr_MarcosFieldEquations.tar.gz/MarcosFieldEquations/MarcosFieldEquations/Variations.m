(*==============*)
(*  Variations  *)
(*==============*)

Comment@"Now we remind ourselves about the derivatives with respect to the translational gauge field of some quantities.";

Comment@"The lapse function.";

Expr=Lapse[];
DisplayExpression@Expr;
Expr//=CD[-m];
Expr//=ToNewCanonical;
DisplayExpression@Expr;

Comment@"The spatial measure.";

Expr=J[];
DisplayExpression@Expr;
Expr//=CD[-m];
Expr//=ToNewCanonical;
DisplayExpression@Expr;

Comment@"The inverse gauge field.";

Expr=H[-i,n];
DisplayExpression@Expr;
Expr//=CD[-m];
Expr//=ToNewCanonical;
DisplayExpression@Expr;

Comment@"Now that the dependence of the contorsion correction to the second-order Lagrangian on the translational gauge field has been made clear, we can use the above derivative laws to reconstruct the variational derivative of the correction.";

Expr=(TorsionlessTau[m,-k]
	+VarD[B[k,-m],CD][MatterLagrangianCorrection]
	+VarD[Lapse[],CD][MatterLagrangianCorrection]Lapse[]H[-l,m]V[l]V[-k]
	+VarD[J[],CD][MatterLagrangianCorrection]J[](H[-k,m]-H[-l,m]V[l]V[-k])
	-VarD[H[-i,n],CD][MatterLagrangianCorrection]H[-i,m]H[-k,n]);

Expr//=ToNewCanonical;
Expr=Expr/.SigmaRomanToSigma;
Expr//=ToNewCanonical;
DisplayExpression@Expr;
Expr=Expr/.ContorsionToTorsion;
Expr//=ToNewCanonical;
SplitExpression=Expr;
DisplayExpression@Expr;

Comment@"We are now ready to write a rule which converts the usual HiGGS stress-energy tensor into torsion-free and torsionful parts.";

SplitStressEnergy=MakeRule[{Tau[m,-k],
	Evaluate@SplitExpression},
	MetricOn->All,ContractMetrics->True];

Expr=Tau[m,-k];
DisplayExpression@Expr;
Expr=Expr/.SplitStressEnergy;
Expr//=ToNewCanonical;
DisplayExpression@Expr;

Comment@"Now we will also write a rule to invert this.";

CombineStressEnergy=MakeQuotientRule[{TorsionlessTau[m,-k],
	Tau[m,-k]-Evaluate@(Tau[m,-k]/.SplitStressEnergy)},
	MetricOn->All,ContractMetrics->True];

Expr=TorsionlessTau[m,-k];
DisplayExpression@Expr;
Expr=Expr/.CombineStressEnergy;
Expr//=ToNewCanonical;
DisplayExpression@Expr;
