(*======================*)
(*  GeneralisedMomenta  *)
(*======================*)

Subsection@"The generalised momenta";

Comment@"Having done this, we define the generalised momenta associated with this subset of multiplier-constrained Poincaré gauge theory. These quantities are defined on p. 50 of Blagojević.";

BGPiSymb="\!\(\*SubscriptBox[\(\[Pi]\), \(\[ScriptB]\)]\)";
DefTensor[BGPi[-i,k,l],M4,PrintAs->xAct`HiGGS`Private`SymbolBuild[BGPiSymb]];
AGPiSymb="\!\(\*SubscriptBox[\(\[Pi]\), \(\[ScriptCapitalA]\)]\)";
DefTensor[AGPi[-i,-j,k,l],M4,Antisymmetric[{-i,-j}],PrintAs->xAct`HiGGS`Private`SymbolBuild[AGPiSymb]];

BGPiDefinition=
	-2Lapse[]J[](
			2( 
			Bet1 PT1[-x,y,z,-i,k,l]
			+Bet2 PT2[-x,y,z,-i,k,l]
			+Bet3 PT3[-x,y,z,-i,k,l])T[x,-y,-z]
			+( 
				cBet1 PT1[-x,y,z,-i,k,l]
				+cBet2 PT2[-x,y,z,-i,k,l]
				+cBet3 PT3[-x,y,z,-i,k,l]
			)TLambda[x,-y,-z]
		)/.ToTheory;

BGPiDefinition=BGPiDefinition/.PActivate;
BGPiDefinition//=ToNewCanonical;
BGPiDefinition=BGPiDefinition/.ToStrengths;
BGPiDefinition//=ToNewCanonical;
BGPiDefinition//=CollectTensors;


AGPiDefinition=
	-4Lapse[]J[](
			2( 
			Alp1 PR1[-x,-w,y,z,-i,-j,k,l]
			+ Alp2 PR2[-x,-w,y,z,-i,-j,k,l]
			+ Alp3 PR3[-x,-w,y,z,-i,-j,k,l]
			+ Alp4 PR4[-x,-w,y,z,-i,-j,k,l]
			+ Alp5 PR5[-x,-w,y,z,-i,-j,k,l]
			+ Alp6 PR6[-x,-w,y,z,-i,-j,k,l])R[x,w,-y,-z]
			+( 
				cAlp1 PR1[-x,-w,y,z,-i,-j,k,l]
				+ cAlp2 PR2[-x,-w,y,z,-i,-j,k,l]
				+ cAlp3 PR3[-x,-w,y,z,-i,-j,k,l]
				+ cAlp4 PR4[-x,-w,y,z,-i,-j,k,l]
				+ cAlp5 PR5[-x,-w,y,z,-i,-j,k,l]
				+ cAlp6 PR6[-x,-w,y,z,-i,-j,k,l]
			)RLambda[x,w,-y,-z]
		)+2Lapse[]J[]MPl^2 Antisymmetrize[Antisymmetrize[G[-i,k]G[-j,l],{-i,-j}],{k,l}]/.ToTheory;

AGPiDefinition=AGPiDefinition/.PActivate;
AGPiDefinition//=ToNewCanonical;
AGPiDefinition=AGPiDefinition/.ToStrengths;
AGPiDefinition//=ToNewCanonical;
AGPiDefinition//=CollectTensors;

BGPiActivate=MakeRule[{BGPi[-i,k,l],Evaluate@BGPiDefinition},MetricOn->All,ContractMetrics->True];
AGPiActivate=MakeRule[{AGPi[-i,-j,k,l],Evaluate@AGPiDefinition},MetricOn->All,ContractMetrics->True];
GPiActivate=Join[BGPiActivate,AGPiActivate];

Comment@"The translational generalised momenta.";

Expr=BGPi[-i,k,l];
DisplayExpression@Expr;
Expr=Expr/.GPiActivate;
Expr//=ToCanonical;
Expr//=ScreenDollarIndices;
DisplayExpression@Expr;

Comment@"The rotational generalised momenta.";

Expr=AGPi[-i,-j,k,l];
DisplayExpression@Expr;
Expr=Expr/.GPiActivate;
Expr//=ToCanonical;
Expr//=ScreenDollarIndices;
DisplayExpression@Expr;

Comment@"These generalised momenta are obtained from the Lagrangian represented in Eq. (4) of arXiv:2205.13534, with most of the coupling constants set to zero as per the above restrictions. Note that this Lagrangian differs from the most general Lagrangian represented in Blagojević by the use of so-called geometric multiplier fields. These are multipliers which can disable all of the Riemann-Cartan or torsion tensors, but which may typically only be used piecemeal to disable select portions of said tensors. It is this latter use-case which we reaslise in our letter, disabling only the tensor part of the torsion.";

Comment@"Another note to be made here is about the caligraphic J and N symbols. Their appearance is an unfortunate side-effect of recycling the Hamiltonian-based HiGGS package to work on Lagrangian problems: these quantities are the measure on the foliation and the Lapse function, respectively, and their product is simply the determinant of the translational gauge field, (which is equivalent to the square root of the negative metric determinant).";
